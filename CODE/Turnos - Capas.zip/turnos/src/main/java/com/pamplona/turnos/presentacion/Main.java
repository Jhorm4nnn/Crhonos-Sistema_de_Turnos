package com.pamplona.turnos.presentacion;

import com.pamplona.turnos.datos.ClienteRepository;
import com.pamplona.turnos.datos.ProfesionalRepository;
import com.pamplona.turnos.datos.TurnoRepository;
import com.pamplona.turnos.negocio.ClienteService;
import com.pamplona.turnos.negocio.ProfesionalService;
import com.pamplona.turnos.negocio.TurnoService;

import java.nio.file.Path;
import java.time.Clock;

/** Punto de entrada: arma las capas (datos -> negocio -> presentacion). */
public class Main {

    public static void main(String[] args) {
        Path carpeta = Path.of(args.length > 0 ? args[0] : "data");

        ClienteRepository clienteRepo = new ClienteRepository(carpeta);
        ProfesionalRepository profRepo = new ProfesionalRepository(carpeta);
        TurnoRepository turnoRepo = new TurnoRepository(carpeta);

        ClienteService clienteService = new ClienteService(clienteRepo);
        ProfesionalService profService = new ProfesionalService(profRepo);
        TurnoService turnoService = new TurnoService(turnoRepo, clienteRepo, profRepo, Clock.systemDefaultZone());

        new ConsolaApp(clienteService, profService, turnoService).iniciar();
    }
}
