package com.pamplona.turnos.negocio;

final class Validaciones {

    private Validaciones() { }

    static String textoObligatorio(String valor, String campo) {
        if (valor == null || valor.isBlank()) {
            throw new ReglaNegocioException(campo + " es obligatorio.");
        }
        valor = valor.trim();
        if (valor.contains(";")) {
            throw new ReglaNegocioException(campo + " no puede contener el caracter ';'.");
        }
        return valor;
    }
}
