package com.pamplona.turnos.negocio;

import com.pamplona.turnos.datos.ClienteRepository;
import com.pamplona.turnos.datos.ProfesionalRepository;
import com.pamplona.turnos.datos.TurnoRepository;
import com.pamplona.turnos.dominio.Profesional;
import com.pamplona.turnos.dominio.Turno;

import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

public class TurnoService {

    private final TurnoRepository turnos;
    private final ClienteRepository clientes;
    private final ProfesionalRepository profesionales;
    private final Clock reloj;

    public TurnoService(TurnoRepository turnos, ClienteRepository clientes,
                        ProfesionalRepository profesionales, Clock reloj) {
        this.turnos = turnos;
        this.clientes = clientes;
        this.profesionales = profesionales;
        this.reloj = reloj;
    }

    /** HU-2 + HU-3: crear turno validando existencia, fecha futura, disponibilidad y cruces. */
    public Turno crear(int clienteId, int profesionalId, LocalDate fecha, LocalTime hora) {
        if (clientes.buscarPorId(clienteId).isEmpty()) {
            throw new ReglaNegocioException("No existe un cliente con id " + clienteId + ".");
        }
        Profesional prof = profesionales.buscarPorId(profesionalId)
                .orElseThrow(() -> new ReglaNegocioException("No existe un profesional con id " + profesionalId + "."));
        validarSlot(prof, fecha, hora, null);
        return turnos.guardar(clienteId, profesionalId, fecha, hora);
    }

    /** HU-4: cancelar un turno existente. */
    public Turno cancelar(int turnoId) {
        Turno t = buscarAgendado(turnoId);
        t.cancelar();
        turnos.actualizar();
        return t;
    }

    /** HU-4: reprogramar, volviendo a validar el no solapamiento (HU-3). */
    public Turno reprogramar(int turnoId, LocalDate nuevaFecha, LocalTime nuevaHora) {
        Turno t = buscarAgendado(turnoId);
        Profesional prof = profesionales.buscarPorId(t.getProfesionalId())
                .orElseThrow(() -> new ReglaNegocioException("El profesional del turno ya no existe."));
        validarSlot(prof, nuevaFecha, nuevaHora, t);
        t.reprogramar(nuevaFecha, nuevaHora);
        turnos.actualizar();
        return t;
    }

    /** HU-5: consultar turnos; cualquier filtro en null se ignora y se pueden combinar. */
    public List<Turno> consultar(Integer profesionalId, Integer clienteId, LocalDate desde, LocalDate hasta) {
        if (desde != null && hasta != null && desde.isAfter(hasta)) {
            throw new ReglaNegocioException("La fecha 'desde' no puede ser posterior a 'hasta'.");
        }
        return turnos.listar().stream()
                .filter(t -> profesionalId == null || t.getProfesionalId() == profesionalId)
                .filter(t -> clienteId == null || t.getClienteId() == clienteId)
                .filter(t -> desde == null || !t.getFecha().isBefore(desde))
                .filter(t -> hasta == null || !t.getFecha().isAfter(hasta))
                .sorted((a, b) -> a.getInicio().compareTo(b.getInicio()))
                .collect(Collectors.toList());
    }

    private Turno buscarAgendado(int turnoId) {
        Turno t = turnos.buscarPorId(turnoId)
                .orElseThrow(() -> new ReglaNegocioException("No existe un turno con id " + turnoId + "."));
        if (t.getEstado() == Turno.Estado.CANCELADO) {
            throw new ReglaNegocioException("El turno " + turnoId + " ya esta cancelado.");
        }
        return t;
    }

    private void validarSlot(Profesional prof, LocalDate fecha, LocalTime hora, Turno ignorar) {
        if (fecha == null || hora == null) {
            throw new ReglaNegocioException("La fecha y la hora son obligatorias.");
        }
        if (!LocalDateTime.of(fecha, hora).isAfter(LocalDateTime.now(reloj))) {
            throw new ReglaNegocioException("La fecha y hora deben ser posteriores a la actual.");
        }
        LocalTime fin = hora.plusMinutes(Turno.DURACION_MIN);
        if (hora.isBefore(prof.getHoraInicio()) || fin.isAfter(prof.getHoraFin()) || fin.isBefore(hora)) {
            throw new ReglaNegocioException("El horario esta fuera de la disponibilidad del profesional ("
                    + prof.getHoraInicio() + " a " + prof.getHoraFin() + ").");
        }
        for (Turno t : turnos.listar()) {
            boolean mismo = ignorar != null && t.getId() == ignorar.getId();
            if (!mismo && t.getProfesionalId() == prof.getId()
                    && t.getEstado() == Turno.Estado.AGENDADO && t.seCruzaCon(fecha, hora)) {
                throw new ReglaNegocioException("El profesional ya tiene un turno que se cruza con ese horario ("
                        + t.getFecha() + " " + t.getHora() + " a " + t.getHoraFin() + ").");
            }
        }
    }
}
