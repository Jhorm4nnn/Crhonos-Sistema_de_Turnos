package com.pamplona.turnos.negocio;

import com.pamplona.turnos.datos.ClienteRepository;
import com.pamplona.turnos.dominio.Cliente;

import java.util.List;

public class ClienteService {

    private final ClienteRepository repo;

    public ClienteService(ClienteRepository repo) {
        this.repo = repo;
    }

    /** HU-1: registrar cliente con campos obligatorios, sin duplicados. */
    public Cliente registrar(String nombre, String contacto) {
        nombre = Validaciones.textoObligatorio(nombre, "El nombre");
        contacto = Validaciones.textoObligatorio(contacto, "El contacto");
        for (Cliente c : repo.listar()) {
            if (c.getNombre().equalsIgnoreCase(nombre) && c.getContacto().equalsIgnoreCase(contacto)) {
                throw new ReglaNegocioException("Ya existe un cliente con ese nombre y contacto.");
            }
        }
        return repo.guardar(nombre, contacto);
    }

    public List<Cliente> listar() {
        return repo.listar();
    }
}
