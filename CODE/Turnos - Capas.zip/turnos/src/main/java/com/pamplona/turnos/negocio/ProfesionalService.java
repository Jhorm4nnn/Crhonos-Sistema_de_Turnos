package com.pamplona.turnos.negocio;

import com.pamplona.turnos.datos.ProfesionalRepository;
import com.pamplona.turnos.dominio.Profesional;

import java.time.LocalTime;
import java.util.List;

public class ProfesionalService {

    private final ProfesionalRepository repo;

    public ProfesionalService(ProfesionalRepository repo) {
        this.repo = repo;
    }

    /** HU-1: registrar profesional con nombre y horario de disponibilidad, sin duplicados. */
    public Profesional registrar(String nombre, LocalTime inicio, LocalTime fin) {
        nombre = Validaciones.textoObligatorio(nombre, "El nombre");
        if (inicio == null || fin == null) {
            throw new ReglaNegocioException("El horario de disponibilidad es obligatorio.");
        }
        if (!inicio.isBefore(fin)) {
            throw new ReglaNegocioException("La hora de inicio debe ser anterior a la hora de fin.");
        }
        for (Profesional p : repo.listar()) {
            if (p.getNombre().equalsIgnoreCase(nombre)) {
                throw new ReglaNegocioException("Ya existe un profesional con ese nombre.");
            }
        }
        return repo.guardar(nombre, inicio, fin);
    }

    public List<Profesional> listar() {
        return repo.listar();
    }
}
