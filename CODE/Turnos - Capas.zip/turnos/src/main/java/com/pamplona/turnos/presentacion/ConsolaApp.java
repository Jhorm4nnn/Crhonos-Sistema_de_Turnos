package com.pamplona.turnos.presentacion;

import com.pamplona.turnos.dominio.Cliente;
import com.pamplona.turnos.dominio.Profesional;
import com.pamplona.turnos.dominio.Turno;
import com.pamplona.turnos.negocio.ClienteService;
import com.pamplona.turnos.negocio.ProfesionalService;
import com.pamplona.turnos.negocio.ReglaNegocioException;
import com.pamplona.turnos.negocio.TurnoService;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

/** Capa de presentacion: solo lee datos, llama a la capa de negocio y muestra resultados. */
public class ConsolaApp {

    private final ClienteService clienteService;
    private final ProfesionalService profService;
    private final TurnoService turnoService;
    private final Scanner in = new Scanner(System.in);

    public ConsolaApp(ClienteService c, ProfesionalService p, TurnoService t) {
        this.clienteService = c;
        this.profService = p;
        this.turnoService = t;
    }

    public void iniciar() {
        System.out.println("=== SISTEMA DE GENERACION DE TURNOS ===");
        try {
            while (true) {
                System.out.println("\n1. Registrar cliente");
                System.out.println("2. Registrar profesional");
                System.out.println("3. Crear turno");
                System.out.println("4. Cancelar turno");
                System.out.println("5. Reprogramar turno");
                System.out.println("6. Consultar turnos");
                System.out.println("7. Listar clientes y profesionales");
                System.out.println("0. Salir");
                String opcion = leer("Opcion");
                if (opcion.equals("0")) {
                    System.out.println("Hasta luego.");
                    return;
                }
                ejecutar(opcion);
            }
        } catch (NoSuchElementException fin) {
            System.out.println("\nEntrada finalizada.");
        }
    }

    private void ejecutar(String opcion) {
        try {
            switch (opcion) {
                case "1" -> registrarCliente();
                case "2" -> registrarProfesional();
                case "3" -> crearTurno();
                case "4" -> cancelarTurno();
                case "5" -> reprogramarTurno();
                case "6" -> consultarTurnos();
                case "7" -> listarTodo();
                default -> System.out.println("Opcion invalida.");
            }
        } catch (ReglaNegocioException | EntradaInvalidaException e) {
            System.out.println("ERROR: " + e.getMessage());
        } catch (RuntimeException e) {
            // HU-8: no se exponen detalles tecnicos al usuario.
            System.out.println("ERROR: ocurrio un problema inesperado. Intente de nuevo.");
        }
    }

    private void registrarCliente() {
        Cliente c = clienteService.registrar(leer("Nombre"), leer("Contacto (telefono/correo)"));
        System.out.println("Cliente registrado: " + c);
    }

    private void registrarProfesional() {
        String nombre = leer("Nombre");
        LocalTime ini = leerHora("Hora inicio disponibilidad (HH:mm)");
        LocalTime fin = leerHora("Hora fin disponibilidad (HH:mm)");
        Profesional p = profService.registrar(nombre, ini, fin);
        System.out.println("Profesional registrado: " + p);
    }

    private void crearTurno() {
        int cliente = leerEntero("Id del cliente");
        int prof = leerEntero("Id del profesional");
        LocalDate fecha = leerFecha("Fecha (AAAA-MM-DD)");
        LocalTime hora = leerHora("Hora (HH:mm)");
        Turno t = turnoService.crear(cliente, prof, fecha, hora);
        System.out.println("Turno creado: " + describir(t));
    }

    private void cancelarTurno() {
        Turno t = turnoService.cancelar(leerEntero("Id del turno"));
        System.out.println("Turno cancelado: " + describir(t));
    }

    private void reprogramarTurno() {
        int id = leerEntero("Id del turno");
        LocalDate fecha = leerFecha("Nueva fecha (AAAA-MM-DD)");
        LocalTime hora = leerHora("Nueva hora (HH:mm)");
        Turno t = turnoService.reprogramar(id, fecha, hora);
        System.out.println("Turno reprogramado: " + describir(t));
    }

    private void consultarTurnos() {
        System.out.println("Deje vacio los filtros que no quiera usar.");
        Integer prof = leerEnteroOpcional("Id del profesional");
        Integer cli = leerEnteroOpcional("Id del cliente");
        LocalDate desde = leerFechaOpcional("Desde (AAAA-MM-DD)");
        LocalDate hasta = leerFechaOpcional("Hasta (AAAA-MM-DD)");
        List<Turno> lista = turnoService.consultar(prof, cli, desde, hasta);
        if (lista.isEmpty()) {
            System.out.println("No hay turnos para esos filtros.");
        }
        lista.forEach(t -> System.out.println(describir(t)));
    }

    private void listarTodo() {
        System.out.println("-- Clientes --");
        clienteService.listar().forEach(System.out::println);
        System.out.println("-- Profesionales --");
        profService.listar().forEach(System.out::println);
    }

    private String describir(Turno t) {
        return "Turno #" + t.getId() + " | cliente " + t.getClienteId() + " | profesional " + t.getProfesionalId()
                + " | " + t.getFecha() + " " + t.getHora() + "-" + t.getHoraFin() + " | " + t.getEstado();
    }

    // ---- lectura y conversion de entradas ----

    private String leer(String etiqueta) {
        System.out.print(etiqueta + ": ");
        return in.nextLine().trim();
    }

    private int leerEntero(String etiqueta) {
        String s = leer(etiqueta);
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            throw new EntradaInvalidaException("'" + s + "' no es un numero valido.");
        }
    }

    private Integer leerEnteroOpcional(String etiqueta) {
        String s = leer(etiqueta);
        if (s.isEmpty()) {
            return null;
        }
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            throw new EntradaInvalidaException("'" + s + "' no es un numero valido.");
        }
    }

    private LocalDate leerFecha(String etiqueta) {
        String s = leer(etiqueta);
        try {
            return LocalDate.parse(s);
        } catch (DateTimeParseException e) {
            throw new EntradaInvalidaException("Fecha invalida. Use el formato AAAA-MM-DD (ej. 2026-10-15).");
        }
    }

    private LocalDate leerFechaOpcional(String etiqueta) {
        String s = leer(etiqueta);
        if (s.isEmpty()) {
            return null;
        }
        try {
            return LocalDate.parse(s);
        } catch (DateTimeParseException e) {
            throw new EntradaInvalidaException("Fecha invalida. Use el formato AAAA-MM-DD (ej. 2026-10-15).");
        }
    }

    private LocalTime leerHora(String etiqueta) {
        String s = leer(etiqueta);
        try {
            return LocalTime.parse(s);
        } catch (DateTimeParseException e) {
            throw new EntradaInvalidaException("Hora invalida. Use el formato HH:mm (ej. 14:30).");
        }
    }

    private static class EntradaInvalidaException extends RuntimeException {
        EntradaInvalidaException(String mensaje) {
            super(mensaje);
        }
    }
}
