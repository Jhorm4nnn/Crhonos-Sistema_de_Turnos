# Sistema de Generacion de Turnos (arquitectura en capas)

Abrir en NetBeans: File > Open Project > carpeta `turnos` (proyecto Maven).
Ejecutar: clic derecho > Run (clase `com.pamplona.turnos.presentacion.Main`).
Los datos se guardan en la carpeta `data/` (se crea sola).

Capas (cada una solo llama a la inferior):
- presentacion -> ConsolaApp, Main
- negocio      -> ClienteService, ProfesionalService, TurnoService
- datos        -> ClienteRepository, ProfesionalRepository, TurnoRepository
- dominio      -> Cliente, Profesional, Turno

Historias: HU-1 registro, HU-2 crear turno, HU-3 no solapamiento,
HU-4 cancelar/reprogramar, HU-5 consultas con filtros, HU-8 mensajes de error claros.
